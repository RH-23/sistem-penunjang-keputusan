### [0.0.1](https://github.com/marcandre/inputevent/releases/tag/v0.0.1)

- The first release