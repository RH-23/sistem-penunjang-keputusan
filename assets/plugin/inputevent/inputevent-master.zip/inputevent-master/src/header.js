/**
 * ${pkg.name} - <%= pkg.description %>
 * ${pkg.homepage}
 * @version v${pkg.version} - (built ${now.format('ddd, MMM Do YYYY, h:mm a')})
 * @author ${pkg.author}
 * @license ${pkg.license}
 */
